import os
import torch
import torch.nn as nn
import traci
import random
import math
import time
from models.split_model import SplitModel, VehicleHead, get_body_model, ViTBody, VehicleTail, DeiTBody, CNNBlockBody
from nodes.vehicle_node_Aggregation import VehicleNode
from nodes.RSU_node_Aggregation import RSUServer
from nodes.Cloud_node_Aggregation import CloudServer
from simulation.sumo_interface import SUMOEnv
from utils.logging_utils import init_csv_logger, log_round_entry, init_rsu_stats_logger, log_rsu_stats
from utils.tools import normalize_id
from utils.eval_utils import evaluate_global_model
from quantizer.adaquant_wrapper import AdaQuantFLQuantizer, quantize_state_dict, get_total_param_dim, log_bit_usage
from quantizer.powersgd_wrapper import PowerSGDOptimizer
from quantizer.base_quantizer import QSGDQuantizer, SignSGDCompressor, TernGradQuantizer
from quantizer.MSCQ import MSCQQuantizer
from quantizer.FedAQQuantizer import FedAQQuantizer



def select_clients(available_clients, num=5):
    return random.sample(available_clients, min(len(available_clients), num))

def find_closest_rsu(vehicle_pos, rsu_dict, threshold=10000):
    closest_rsu = None
    min_dist = float("inf")
    for rsu_id, rsu in rsu_dict.items():
        rsu_pos = rsu.position
        dist = math.hypot(vehicle_pos[0] - rsu_pos[0], vehicle_pos[1] - rsu_pos[1])
        if dist < threshold and dist < min_dist:
            min_dist = dist
            closest_rsu = rsu_id
    return closest_rsu


SUPPORTED_KEYS = ["scene", "timeofday", "weather"]

def federated_training(sumocfg_path, dataset_name, comm_rounds, snr_default, body_model_name, agg_strategy_name, quantizer_name, quantizer_level, initial_lr, alpha, log_path="logs/federated_log.csv"):

    sumo = SUMOEnv(sumocfg_path)
    sumo.start()

    mscq = None  # 用于控制 MSCQ 初始化


    # 统一构造三段模型结构
    vehicle_head = VehicleHead(in_channels=3 if dataset_name.lower() == "bdd" else 1, pretrained=False)
    vehicle_tail = VehicleTail(num_classes=7 if dataset_name.lower() == "bdd" else 10)
    cloud_body = get_body_model(body_model_name)

    cloud = CloudServer(head_template=vehicle_head, tail_template=vehicle_tail, body_model=cloud_body)

    # ✅ 初始化 FedAdam 状态缓存（在构造 cloud 后）
    cloud.head_momentum = {}  # 一阶动量缓存 head
    cloud.head_velocity = {}  # 二阶动量缓存 head
    cloud.tail_momentum = {}  # 一阶动量缓存 tail
    cloud.tail_velocity = {}  # 二阶动量缓存 tail

    rsu_stats_path = "logs/rsu_stats.csv"
    init_csv_logger(log_path)
    init_rsu_stats_logger(rsu_stats_path)

    global_eval_path = "logs/global_eval.csv"
    if not os.path.exists(global_eval_path):
        with open(global_eval_path, "w") as f:
            f.write("round,accuracy\n")

    rsu_map = {}
    rsu_positions = sumo.get_all_rsus()
    for rsu_id, pos in rsu_positions.items():
        rsu_map[rsu_id] = RSUServer(rsu_id, agg_strategy_name, position=pos)

    print("✅ 启动三段式联邦训练")

    z_history = {"head": {}, "tail": {}}
    z_current = {"head": {}, "tail": {}}

    vehicle_node_map = {}
    fedaq = None

    for t in range(comm_rounds):
        print(f"\n🌐 Round {t} ==============================")
        print(f"🧠 当前使用的聚合算法：{agg_strategy_name}")

        total_upload_bits = 0

        for _ in range(80):
            sumo.step()

        active_vehicles = []
        all_veh_ids = sumo.get_vehicles()
        for veh in all_veh_ids:
            #data_id = normalize_id(veh)
            data_id = veh
            if dataset_name.lower() == "mnist":
                data_path = f"data/mnist/partitions/{data_id}_train.pt"
            elif dataset_name.lower() == "bdd":
                data_path = f"data/BDD100K/clients/{data_id}_bdd.pt"
            elif dataset_name.lower() == "cifar10":
                data_path = f"data/cifar10/partitions/{data_id}_train.pt"
            else:
                raise ValueError(f"未知数据集类型：{dataset_name}")
            if os.path.exists(data_path):
                active_vehicles.append(veh)

        print(f"当前活跃车辆数量：{len(active_vehicles)}")
        print(f"当前压缩算法：{quantizer_name}")


        # 下发全局模型
        model_state = cloud.distribute_model()
        for rsu in rsu_map.values():
            rsu.distribute_model(model_state)
            rsu.reset()

        total_upload_time_ms = 0
        num_active_clients = 0

        for client_id in active_vehicles:
            try:
                pos = sumo.get_position(client_id)
                speed = traci.vehicle.getSpeed(client_id)
                connected = sumo.is_connected_to_rsu(client_id)
                rsu_id = find_closest_rsu(pos, rsu_map)

                bits_used_this_client = 0

                # 若该节点首次出现，则创建实例
                if client_id not in vehicle_node_map:
                    node = VehicleNode(client_id, pos, speed, dataset_name, agg_strategy_name,
                                       is_connected=bool(rsu_id), snr=snr_default)
                    vehicle_node_map[client_id] = node
                    print(f"初始化车辆节点：{client_id}")
                else:
                    node = vehicle_node_map[client_id]
                    # ✅ 更新当前位置信息
                    node.position = pos
                    node.speed = speed
                    node.is_connected = bool(rsu_id)
                    node.snr = snr_default
                    print(f"已有车辆节点：{client_id}")

                trained, uploaded = False, False
                if rsu_id:
                    rsu_map[rsu_id].bind_vehicle(client_id)

                    # 加载 cloud 分发的 head 和 tail 权重
                    local_head = VehicleHead()
                    local_tail = VehicleTail(num_classes=7 if dataset_name.lower() == "bdd" else 10)
                    local_head.load_state_dict(rsu_map[rsu_id].global_head)
                    local_tail.load_state_dict(rsu_map[rsu_id].global_tail)

                    min_lr = 0.001
                    decay_rate = 0.95
                    client_lr = max(min_lr, initial_lr * (decay_rate ** t))  # 每轮衰减 5%

                    # 训练本地模型
                    delta = node.local_train({
                        "head": local_head,
                        "tail": local_tail,
                        "body": cloud.body_model  # 云端固定推理模型
                    }, lr=client_lr)

                    print(f"[{client_id}] 当前本地训练学习率 lr = {client_lr}")

                    trained = node.eligible_to_train
                    uploaded = node.eligible_to_upload and (delta is not None)


                    if uploaded:
                        print(f"第{t}训练结束，开始车辆节点{client_id}的本地模型上传")
                        # ============ 1. 开始计时 ============
                        start = time.perf_counter()
                        # 梯度量化阶段
                        if quantizer_name.lower() == "adaquant":
                            # === Step 1: 获取模型维度 d ===
                            head_dim = get_total_param_dim(delta["head"])
                            tail_dim = get_total_param_dim(delta["tail"])
                            total_dim = head_dim + tail_dim

                            # === Step 2: 初始化量化器，并动态调整 s_k* ===
                            final_loss = delta.get("final_loss", 0.1)
                            quantizer = AdaQuantFLQuantizer(d=total_dim, level=quantizer_level)
                            quantizer.update_s(loss=final_loss, lr=0.01)

                            # === Step 3: 对模型参数进行量化 ===
                            delta["head"] = quantize_state_dict(delta["head"], quantizer)
                            delta["tail"] = quantize_state_dict(delta["tail"], quantizer)

                            bits_used_this_client = quantizer.estimate_bits(quantizer.s)
                            log_bit_usage("logs/Adaquant_bit_usage.csv", t, client_id, bits_used_this_client)
                        elif quantizer_name.lower() == "powersgd":
                            if t == 0:
                                total_dim = get_total_param_dim(delta["head"]) + get_total_param_dim(delta["tail"])
                                powersgd = PowerSGDOptimizer(rank=8, d=total_dim)
                            layer_shapes = []
                            for part in ["head", "tail"]:
                                for name, tensor in delta[part].items():
                                    if tensor.ndim == 2:
                                        compressed = powersgd.step(f"{part}_{name}", tensor, tensor)
                                        delta[part][name] = compressed
                                        layer_shapes.append(tensor.shape)
                                    else:
                                        # 非二维直接上传
                                        pass
                            bits_used_this_client = powersgd.estimate_bits(layer_shapes)
                            log_bit_usage("logs/PowerSGD_bit_usage.csv", t, client_id, bits_used_this_client)
                        # === SignSGD ===
                        elif quantizer_name.lower() == "signsgd":
                            if t<3:
                                print(f"第{t}轮训练，全精度上传")
                                bits_used_this_client = get_total_param_dim(delta["head"]) * 32 + get_total_param_dim(
                                    delta["tail"]) * 32
                            else:
                                print(f"第{t}轮训练，signsgd量化")
                                signsgd = SignSGDCompressor()
                                total_bits = 0
                                for part in ["head", "tail"]:
                                    for name, tensor in delta[part].items():
                                        flat = tensor.view(-1)
                                        q, _ = signsgd.quantize(flat)
                                        delta[part][name] = q.view_as(tensor)
                                        total_bits += flat.numel()
                                bits_used_this_client = signsgd.estimate_bits(total_bits)
                                log_bit_usage("logs/SignSGD_bit_usage.csv", t, client_id, bits_used_this_client)
                        # === TernGrad ===
                        elif quantizer_name.lower() == "terngrad":
                            if t<3:
                                print(f"第{t}轮训练，全精度上传")
                                bits_used_this_client = get_total_param_dim(delta["head"]) * 32 + get_total_param_dim(
                                    delta["tail"]) * 32
                            else:
                                print(f"第{t}轮训练，terngrad量化")
                                tern = TernGradQuantizer()
                                total_bits = 0
                                for part in ["head", "tail"]:
                                    for name, tensor in delta[part].items():
                                        flat = tensor.view(-1)
                                        q, _ = tern.quantize(flat)
                                        delta[part][name] = q.view_as(tensor)
                                        total_bits += flat.numel()
                                bits_used_this_client = tern.estimate_bits(total_bits)
                                log_bit_usage("logs/TernGrad_bit_usage.csv", t, client_id, bits_used_this_client)
                        elif quantizer_name.lower() == "qsgd":
                            if t < 3:
                                print(f"第{t}轮训练，全精度上传")
                                bits_used_this_client = get_total_param_dim(delta["head"]) * 32 + get_total_param_dim(
                                    delta["tail"]) * 32
                            else:
                                print(f"第{t}轮训练，QSGD量化")
                                qsgd= QSGDQuantizer(level=quantizer_level)
                                bits_used_this_client = 0
                                orig_bits_total = 0
                                compressed_bits_total = 0
                                for part in ["head", "tail"]:
                                    for name, tensor in delta[part].items():
                                        flat = tensor.view(-1)
                                        q,_ = qsgd.quantize(flat)
                                        delta[part][name] = q.view_as(tensor)
                                        # 每层原始bits
                                        orig_bits_total += flat.numel() * 32
                                        # 每层压缩bits
                                        bits = qsgd.estimate_bits(d=flat.numel())
                                        compressed_bits_total += bits
                                        bits_used_this_client += bits
                                log_bit_usage("logs/QSGD_bit_usage.csv", t, client_id, bits_used_this_client)
                                # 只输出一条
                                if compressed_bits_total > 0:
                                    print(
                                        f"[QSGD][{client_id}] 原始通信: {orig_bits_total} bits，压缩后: {compressed_bits_total} bits，压缩率 ≈ {orig_bits_total / compressed_bits_total:.2f}×")

                        elif quantizer_name.lower() == "mscq":
                            if t < 1:
                                qsgd = QSGDQuantizer(level=quantizer_level)
                                for part in ["head", "tail"]:
                                    for name, tensor in delta[part].items():
                                        flat = tensor.view(-1)
                                        q, norm = qsgd.quantize(flat)
                                        delta[part][name] = q.view_as(tensor)
                            else:
                                if mscq is None:
                                    mscq = MSCQQuantizer(b_min=32, b_max=128)
                                for name, tensor in delta["head"].items():
                                    if tensor.ndim != 2:
                                        continue
                                    z_now = tensor.view(-1)
                                    z_prev = z_history["head"].get(name)

                                    # 首次或 shape 不一致则跳过本次压缩
                                    if z_prev is None or z_prev.shape != z_now.shape:
                                        print(f"[MSCQ Warning] Skip head-{name} due to shape mismatch.")
                                        z_prev = z_now
                                    # 执行量化
                                    q_tensor, bits = mscq.quantize_with_adaptive_bits(z_now, z_prev, z_now,
                                                                                      part="head",
                                                                                      name=f"head_{name}")
                                    delta["head"][name] = q_tensor.view_as(tensor)
                                    # ==== 求该层上传 bits ====
                                    #bits_this = mscq.estimate_bits(z_now.numel(), bits)
                                    bits_this = mscq.estimate_bits_csv(z_now.numel(), bits)
                                    bits_used_this_client += bits_this

                                    log_bit_usage("logs/MSCQ_bit_usage.csv", t, client_id,
                                                  mscq.estimate_bits(z_now.numel(), bits))

                                    # 更新历史记录
                                    z_history["head"][name] = z_now
                                    z_current["head"][name] = z_now

                                # === TAIL 参数拼接统一量化 ===
                                tail_param_names, tail_flat_grads, tail_slices = [], [], []

                                pointer = 0
                                for name, tensor in delta["tail"].items():
                                    if tensor.ndim != 2:
                                        continue
                                    flat = tensor.view(-1)
                                    tail_param_names.append(name)
                                    tail_flat_grads.append(flat)
                                    tail_slices.append((pointer, pointer + flat.numel()))
                                    pointer += flat.numel()

                                if tail_flat_grads:
                                    tail_concat = torch.cat(tail_flat_grads)
                                    z_now_tail = tail_concat
                                    z_prev_tail = z_history["tail"].get("mlp_all")

                                    if z_prev_tail is None or z_prev_tail.shape != z_now_tail.shape:
                                        print(f"[MSCQ Warning] Skip tail-MLP due to shape mismatch.")
                                        z_prev_tail = z_now_tail

                                    q_concat, bits = mscq.quantize_with_adaptive_bits(z_now_tail, z_prev_tail,
                                                                                      z_now_tail,
                                                                                      part="tail", name="mlp_all")

                                    bits_this = mscq.estimate_bits(z_now_tail.numel(), bits)
                                    bits_used_this_client += bits_this

                                    log_bit_usage("logs/MSCQ_bit_usage.csv", t, client_id,
                                                  mscq.estimate_bits(z_now_tail.numel(), bits))

                                    # 将量化后的拼接向量切分写回 delta
                                    for name, (start, end) in zip(tail_param_names, tail_slices):
                                        delta["tail"][name] = q_concat[start:end].view_as(delta["tail"][name])

                                    # 更新历史记录
                                    z_history["tail"]["mlp_all"] = z_now_tail
                                    z_current["tail"]["mlp_all"] = z_now_tail
                                    print(f"[MSCQ] Rounds{t}.")
                        elif quantizer_name.lower() == "fedaq":
                            #print(f"第{t}轮训练，FedAQ量化")

                            if t == 0 or fedaq is None:
                                # Step 1: 构造 state_template（用于记录每层名与结构）
                                state_template = {
                                    f"{part}.{name}": tensor
                                    for part in ["head", "tail"]
                                    for name, tensor in delta[part].items()
                                    if tensor.dtype.is_floating_point
                                }

                                # Step 2: 构造每层量化 bit 配置（这里统一设为 8）
                                bit_config = {name: 8 for name in state_template.keys()}

                                # Step 3: 初始化 FedAQ 量化器（是否使用误差反馈由 use_ef 控制）
                                fedaq = FedAQQuantizer(
                                    layer_bit_config=bit_config,
                                    state_dict_template=state_template,
                                    use_ef=False  # ✅ 若要复现原文设为 False，增强稳定性设为 True
                                )

                            # ============ 调用量化器进行 Δw 量化 ============

                            # Step 4: 合并 head 与 tail 为一个扁平化的 dict
                            combined_state = {
                                f"{part}.{name}": tensor
                                for part in ["head", "tail"]
                                for name, tensor in delta[part].items()
                            }

                            # Step 5: 使用 fedaq 量化整个 state dict
                            quantized_state = fedaq.quantize_state_dict(combined_state)

                            # Step 6: 将量化后的结果写回 delta（分别赋回 head / tail）
                            for full_name, tensor in quantized_state.items():
                                part, name = full_name.split(".", 1)
                                delta[part][name] = tensor

                            # ✅ Step 7: 可选：记录通信 bit 开销
                            bits_used_this_client = fedaq.estimate_total_bits()
                            log_bit_usage("logs/FedAQ_bit_usage.csv", t, client_id, bits_used_this_client)
                        elif quantizer_name.lower() == "none":
                            # 不压缩，直接全精度上传
                            bits_used_this_client = get_total_param_dim(delta["head"]) * 32 + get_total_param_dim(
                                delta["tail"]) * 32

                        # ============ 2. 上传到RSU ============
                        rsu_map[rsu_id].receive_update(
                            head_state_dict={"head": delta["head"]},
                            tail_state_dict={"tail": delta["tail"]},
                            sample_num=delta.get("sample_num"),
                            local_steps=delta.get("local_steps")
                        )


                        total_upload_bits += bits_used_this_client  # 注意bits_used必须包含head+tail所有分量

                        # ============ 3. 结束计时 ============
                        end = time.perf_counter()
                        upload_time_ms = (end - start) * 1000
                        total_upload_time_ms += upload_time_ms
                        num_active_clients += 1

                        # ============ 4.1 写入通信延迟日志 ============
                        log_path = f"logs/comm_time_{dataset_name}_{agg_strategy_name}_{alpha}_{body_model_name}_{quantizer_name.lower()}_{len(active_vehicles)}.csv"
                        file_exists = os.path.exists(log_path)
                        with open(log_path, "a") as f:
                            # 若文件首次创建，则写表头
                            if not file_exists or os.stat(log_path).st_size == 0:
                                f.write("round,client_id,quantizer,upload_time_ms,rsu_id\n")
                            f.write(f"{t},{client_id},{quantizer_name},{upload_time_ms:.2f},{rsu_id}\n")

                        # ============ 4.2 写入MSCQ下累积通信延迟日志 ============
                        if num_active_clients % 5 == 0:
                            log_path_batch = f"logs/batch_comm_time_{dataset_name}_{agg_strategy_name}_{alpha}_{body_model_name}_{quantizer_name.lower()}_{len(active_vehicles)}.csv"
                            file_exists = os.path.exists(log_path_batch)
                            with open(log_path_batch, "a") as f:
                                if not file_exists or os.stat(log_path_batch).st_size == 0:
                                    f.write("round,cum_clients,quantizer,cum_upload_time_ms\n")
                                f.write(f"{t},{num_active_clients},{quantizer_name},{total_upload_time_ms:.2f}\n")

                log_round_entry(log_path, [
                    t, client_id, rsu_id or "None", trained, uploaded, round(speed, 2), connected
                ])

            except Exception as e:
                print(f"[Error] {client_id}：{e}")

        # 每轮写一次总bit数
        bits_log_path = f"logs/comm_bits_{dataset_name}_{agg_strategy_name}_{alpha}_{body_model_name}_{quantizer_name.lower()}_{len(active_vehicles)}.csv"
        file_exists = os.path.exists(bits_log_path)
        with open(bits_log_path, "a") as f:
            if not file_exists or os.stat(bits_log_path).st_size == 0:
                f.write("round,quantizer,total_upload_bits\n")
            f.write(f"{t},{quantizer_name},{total_upload_bits}\n")


        # RSU 局部聚合
        head_updates, tail_updates = [], []
        for rsu in rsu_map.values():
            #delta = rsu.local_aggregate()
            if agg_strategy_name == "Fed_Adam":
                delta = rsu.local_aggregate(
                    round_num=t + 1,
                    prev_params={
                        "head": cloud.global_head.state_dict(),
                        "tail": cloud.global_tail.state_dict()
                    },
                    momentums={
                        "head": cloud.head_momentum,
                        "tail": cloud.tail_momentum
                    },
                    velocities={
                        "head": cloud.head_velocity,
                        "tail": cloud.tail_velocity
                    },
                    lr=0.001,
                    beta1=0.9,
                    beta2=0.999,
                    aggregation_strategy=agg_strategy_name
                )
            elif agg_strategy_name == "Fed_AVGM":
                delta = rsu.local_aggregate(
                    round_num=t + 1,
                    prev_params={
                        "head": cloud.global_head.state_dict(),
                        "tail": cloud.global_tail.state_dict()
                    },
                    momentums={
                        "head": cloud.head_momentum,  # 初始为全 0
                        "tail": cloud.tail_momentum
                    },
                    beta=0.9,
                    eta=1.0,
                    aggregation_strategy=agg_strategy_name
                )
            elif agg_strategy_name == "Fed_Nova":
                delta = rsu.local_aggregate(
                    #aggregation_strategy="Fed_Nova",
                    #round_num=rsu.client_sample_nums,
                    #local_steps=rsu.client_local_steps
                )
            elif agg_strategy_name == "Fed_AdaGrad":
                delta = rsu.local_aggregate(
                    round_num=t + 1,
                    prev_params={
                        "head": cloud.global_head.state_dict(),
                        "tail": cloud.global_tail.state_dict()
                    },
                    lr=0.01,
                    epsilon=1e-8,
                    aggregation_strategy=agg_strategy_name
                )
            elif agg_strategy_name == "Fed_MOON":
                delta = rsu.local_aggregate(
                    round_num=t + 1,
                    aggregation_strategy=agg_strategy_name
                )
            else:
                delta = rsu.local_aggregate(
                    round_num=t + 1,
                    aggregation_strategy=agg_strategy_name
                )
            if delta:
                head_updates.append(delta["head"])
                tail_updates.append(delta["tail"])

        cloud.aggregate(head_updates, tail_updates, quantizer_name)

        """
        # ✅ 聚合后立即重新同步至 RSU
        new_model_state = cloud.distribute_model()
        for rsu in rsu_map.values():
            rsu.distribute_model(new_model_state)
            rsu.reset()
        """


        # 评估当前模型（组合 head + body + tail）
        eval_model = torch.nn.Sequential(
            cloud.global_head,
            cloud.body_model,
            cloud.global_tail
        )

        # ✅ 插入 checksum 检查（调试是否每轮模型更新）
        checksum = sum(p.sum().item() for p in eval_model.parameters())
        print(f"[DEBUG] Round {t} 模型 checksum: {checksum:.6f}")

        acc = evaluate_global_model(eval_model, dataset_name)
        print(f"📊 Round {t} 测试集准确率：{acc * 100:.2f}%")

        #with open(global_eval_path, "a") as f:
            #f.write(f"{t},{acc:.4f}\n")

        accuracy_log_path = f"logs/accuracy_{dataset_name}_{agg_strategy_name}_{alpha}_{body_model_name}_{quantizer_name.lower()}_{len(active_vehicles)}.csv"
        file_exists = os.path.exists(accuracy_log_path)
        with open(accuracy_log_path, "a") as f:
            if not file_exists or os.stat(accuracy_log_path).st_size == 0:
                f.write("round,quantizer,test_accuracy\n")
            f.write(f"{t},{quantizer_name},{acc:.4f}\n")

        for rsu_id, rsu in rsu_map.items():
            num_clients = len(rsu.connected_clients)
            print(f"[{rsu_id}] 🚘 本轮服务车辆数：{num_clients}")
            log_rsu_stats(rsu_stats_path, t, rsu_id, num_clients)

            # === 统计每轮最大GPU占用 ===
            if torch.cuda.is_available():
                max_mem = torch.cuda.max_memory_allocated()
                max_mem_mb = max_mem / 1024 / 1024
            else:
                max_mem_mb = 0

            gpu_log_path = f"logs/max_gpu_mem_{dataset_name}_{agg_strategy_name}_{alpha}_{body_model_name}_{quantizer_name.lower()}_{len(active_vehicles)}.csv"
            file_exists = os.path.exists(gpu_log_path)
            with open(gpu_log_path, "a") as f:
                if not file_exists or os.stat(gpu_log_path).st_size == 0:
                    f.write("round,quantizer,max_gpu_mem_mb\n")
                f.write(f"{t},{quantizer_name},{max_mem_mb:.2f}\n")

            # === 重置统计，防止跨轮次继承峰值 ===
            torch.cuda.reset_max_memory_allocated()

        # ✅ 聚合后立即重新同步至 RSU
        new_model_state = cloud.distribute_model()
        for rsu in rsu_map.values():
            rsu.distribute_model(new_model_state)
            rsu.reset()

    sumo.close()
    print(f"\n✅ 训练完成，日志写入：{log_path}")


