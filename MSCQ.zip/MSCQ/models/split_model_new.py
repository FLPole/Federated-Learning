import os
import torch
import torch.nn as nn
import torchvision.models as models
import timm
import torch.nn.functional as F

# ✅ 统一设置全局 device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class SplitModel(nn.Module):
    def __init__(self, head: nn.Module, body: nn.Module, tail: nn.Module):
        super(SplitModel, self).__init__()
        self.head = head
        self.body = body
        self.tail = tail

    def forward(self, x, client_idx=None):
        x = self.head(x)
        x = self.body(x)
        out = self.tail(x)
        return out

class VehicleHead(nn.Module):
    def __init__(self, in_channels=3, out_dim=768, pretrained=False):
        super(VehicleHead, self).__init__()
        resnet = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(resnet.children())[:-2])
        self.proj = nn.Conv2d(2048, out_dim, kernel_size=1)
        self.to(device)

    def forward(self, x):
        x = self.backbone(x)
        x = self.proj(x)
        B, C, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)
        return x

class ViTBody(nn.Module):
    def __init__(self, base_model_name="vit_base_r50_s16_224"):
        super(ViTBody, self).__init__()
        vit = timm.create_model(base_model_name, pretrained=True)

        #current_dir = os.path.dirname(__file__)
        #weight_path = os.path.join(current_dir, "pretrained_models", base_model_name, "pytorch_model.bin")
        #state_dict = torch.load(weight_path, map_location=device)
        #vit.load_state_dict(state_dict)

        self.blocks = vit.blocks
        self.norm = vit.norm
        self.cls_token = vit.cls_token
        self.pos_drop = vit.pos_drop
        self.register_buffer('original_pos_embed', vit.pos_embed[:, 1:, :].to(device))
        self.pos_embed_dim = vit.pos_embed.shape[-1]
        self.to(device)

    def interpolate_pos_encoding(self, x, seq_len):
        B, N, D = x.shape
        orig_num_patches = self.original_pos_embed.shape[1]
        if seq_len == orig_num_patches:
            return self.original_pos_embed
        pos_embed = self.original_pos_embed.reshape(1, int(orig_num_patches ** 0.5), -1, D)
        pos_embed = pos_embed.permute(0, 3, 1, 2)
        new_size = int(seq_len ** 0.5 + 0.5)
        pos_embed = F.interpolate(pos_embed, size=(new_size, new_size), mode='bicubic', align_corners=False)
        pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(1, seq_len, D)
        return pos_embed

    def forward(self, x):
        B, N, D = x.shape
        cls_token = self.cls_token.expand(B, -1, -1).to(x.device)
        pos_embed = self.interpolate_pos_encoding(x, N)
        pos_embed = torch.cat((torch.zeros(1, 1, D, device=x.device), pos_embed), dim=1)
        x = torch.cat((cls_token, x), dim=1)
        x = x + pos_embed
        x = self.pos_drop(x)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return x[:, 0]

class DeiTBody(nn.Module):
    def __init__(self, base_model_name="deit_base_patch16_224"):
        super(DeiTBody, self).__init__()
        model = timm.create_model(base_model_name, pretrained=True)
        self.blocks = model.blocks
        self.norm = model.norm
        self.cls_token = model.cls_token
        self.pos_drop = model.pos_drop
        self.register_buffer('original_pos_embed', model.pos_embed[:, 1:, :].to(device))
        self.pos_embed_dim = model.pos_embed.shape[-1]
        self.to(device)

    def interpolate_pos_encoding(self, x, seq_len):
        B, N, D = x.shape
        orig_N = self.original_pos_embed.shape[1]
        if seq_len == orig_N:
            return self.original_pos_embed
        pos_embed = self.original_pos_embed.reshape(1, int(orig_N**0.5), -1, D)
        pos_embed = pos_embed.permute(0, 3, 1, 2)
        new_size = int(seq_len**0.5 + 0.5)
        pos_embed = F.interpolate(pos_embed, size=(new_size, new_size), mode='bicubic', align_corners=False)
        pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(1, seq_len, D)
        return pos_embed

    def forward(self, x):
        B, N, D = x.shape
        cls_token = self.cls_token.expand(B, -1, -1).to(x.device)
        pos_embed = self.interpolate_pos_encoding(x, N)
        pos_embed = torch.cat((torch.zeros(1, 1, D, device=x.device), pos_embed), dim=1)
        x = torch.cat((cls_token, x), dim=1)
        x = x + pos_embed
        x = self.pos_drop(x)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return x[:, 0]

class CNNBlockBody(nn.Module):
    def __init__(self, in_channels=768, out_channels=768, mid_channels=512):
        super(CNNBlockBody, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, mid_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(mid_channels)
        self.conv2 = nn.Conv1d(mid_channels, out_channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.to(device)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        x = x.squeeze(-1)
        return x

class ResNetBody(nn.Module):
    def __init__(self, in_channels=768, out_dim=768, model_name="resnet101"):
        super(ResNetBody, self).__init__()
        base_model = getattr(models, model_name)(pretrained=True)
        self.conv1 = nn.Conv2d(in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.resnet = nn.Sequential(
            self.conv1,
            base_model.bn1,
            base_model.relu,
            base_model.maxpool,
            base_model.layer1,
            base_model.layer2,
            base_model.layer3,
            base_model.layer4,
            nn.AdaptiveAvgPool2d((1, 1))
        )
        self.fc = nn.Linear(2048, out_dim)
        self.to(device)

    def forward(self, x):
        B, N, D = x.shape
        H = W = int(N ** 0.5)
        assert H * W == N, "输入 patch 数不是平方数，不能 reshape 成图像"
        x = x.transpose(1, 2).reshape(B, D, H, W)
        x = self.resnet(x)
        x = x.view(B, -1)
        x = self.fc(x)
        return x

class VehicleTail(nn.Module):
    def __init__(self, in_dim=768, num_classes=7):
        super(VehicleTail, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, 512),
            nn.ReLU(),
            nn.Linear(512, num_classes)
        )
        self.to(device)

    def forward(self, x):
        return self.mlp(x)

def get_body_model(body_model_name: str):
    model_name = body_model_name.lower()
    if model_name == "cnn":
        print("\U0001F4A1 使用轻量 CNNBlockBody 作为云端模型")
        return CNNBlockBody()
    elif model_name == "vit":
        print("\U0001F4A1 使用 ViTBody 作为云端模型")
        return ViTBody()
    elif model_name == "resnet":
        print("\U0001F4A1 使用 ResNet101 作为云端模型")
        return ResNetBody()
    elif model_name == "deit":
        print("\U0001F4A1 使用 DeiT 作为云端模型")
        return DeiTBody()
    else:
        raise ValueError(f"未知的主体模型类型或暂不支持: {model_name}")
