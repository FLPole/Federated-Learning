import torch
import torch.nn as nn
import math
import os
import random
import torch.nn.functional as F


# === MSCQ 封装类 ===
class MSCQQuantizer:
    def __init__(self, b_min, b_max, alpha=0.5):
        self.b_min = b_min
        self.b_max = b_max
        self.alpha = alpha  # 平滑因子
        self.p_head = None  # 历史参考分布（head）
        self.p_tail = None
        self.prev_bits = {}  # 新增，用于防抖
        self.ef_dict = {}   # 误差反馈缓存

    def cosine_similarity(self, a, b):
        return F.cosine_similarity(a, b, dim=-1).mean()

    def compute_kl(self, q, p):
        kl = (q * (q / (p + 1e-8)).log()).sum()
        return kl

    def update_ref_dist(self, q, part):
        if part == "head":
            if self.p_head is None:
                #self.p_head = q.clone()
                self.p_head = q.clone().to(q.device)
            else:
                self.p_head = self.alpha * self.p_head + (1 - self.alpha) * q
        elif part == "tail":
            if self.p_tail is None:
                #self.p_tail = q.clone()
                self.p_tail = q.clone().to(q.device)
            else:
                self.p_tail = self.alpha * self.p_tail + (1 - self.alpha) * q

    def map_kl_to_bits(self, kl):
        kl_value = kl.detach().item() if isinstance(kl, torch.Tensor) else kl
        b = self.b_min + (self.b_max - self.b_min) * min(1.0, kl_value)
        b = int(round(b))
        b = max(self.b_min, min(self.b_max, b))
        return b

    def quantize(self, grad, bits):
        norm = grad.norm(p=2)
        if norm.item() == 0:
            return torch.zeros_like(grad), norm
        x_unit = grad / norm
        abs_x = x_unit.abs()
        level = (abs_x * bits).floor()
        prob = abs_x * bits - level
        rand = torch.rand_like(prob)
        add = (rand < prob).float()
        q = (level + add) / bits * x_unit.sign()
        return norm * q, norm


    def quantize_with_adaptive_bits(self, grad, z_prev, z_now, part="head", name=""):
        delta = z_now - z_prev
        T = 5.0  # 温度，可调
        delta_norm = (delta - delta.mean()) / (delta.std() + 1e-6)
        q_dist = F.softmax(delta_norm / T, dim=-1)
        self.update_ref_dist(q_dist, part)
        p_dist = self.p_head if part == "head" else self.p_tail
        # 计算KL散度
        kl = self.compute_kl(q_dist, p_dist)
        # KL映射到bit
        bits = self.map_kl_to_bits(kl)
        print(f"[MSCQ] layer={name}, kl={kl.item():.4f}, bits={bits}, T={T}")

        # ==== bit平滑 ====
        prev = self.prev_bits.get(name, bits)

        if bits >= prev:
            # 允许bit直接升高
            pass
        else:
            # 降低时最多降1
            bits = max(prev - 1, bits)
        bits = max(self.b_min, min(self.b_max, bits))
        self.prev_bits[name] = bits



        print(f"[MSCQ] {name}: KL={kl.item():.6f}, bits={bits}")

        # 直接量化，不做误差反馈
        q_grad, _ = self.quantize(grad, bits)
        return q_grad, bits

    def estimate_bits(self, d, bits):
        raw_bits = 32 * d
        compressed_bits = math.ceil(math.log2(bits + 1)) * d + 32
        print(f"[MSCQ] 当前量化等级 b = {bits}，原始通信: {raw_bits} bits，压缩后: {compressed_bits} bits，压缩率 ≈ {raw_bits / compressed_bits:.2f}×")
        return compressed_bits

    def estimate_bits_csv(self, d, bits, log_path="logs/MSCQ_levels_usage.csv", round_num=None, client_id=None):
        raw_bits = 32 * d
        compressed_bits = math.ceil(math.log2(bits + 1)) * d + 32
        compression_ratio = raw_bits / compressed_bits

        # 打印信息
        print(
            f"[MSCQ] 当前量化等级 b = {bits}，原始通信: {raw_bits} bits，压缩后: {compressed_bits} bits，压缩率 ≈ {compression_ratio:.2f}×")

        print(f"[MSCQ Debug] 写入路径为: {os.path.abspath(log_path)}")

        # 写入日志
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        header = "round,client_id,bits_used,raw_bits,compressed_bits,compression_ratio"
        if not os.path.exists(log_path):
            with open(log_path, "w") as f:
                f.write(header + "\n")

        with open(log_path, "a") as f:
            round_str = str(round_num) if round_num is not None else "-"
            client_str = str(client_id) if client_id is not None else "-"
            f.write(f"{round_str},{client_str},{bits},{raw_bits},{compressed_bits},{compression_ratio:.4f}\n")

        return compressed_bits


# === 统一日志函数 ===
def log_bit_usage(bit_logger_path, round_num, client_id, bits_used):
    header = "round,client_id,bits_used"
    if not os.path.exists(bit_logger_path):
        with open(bit_logger_path, "w") as f:
            f.write(header + "\n")
    with open(bit_logger_path, "a") as f:
        f.write(f"{round_num},{client_id},{bits_used}\n")
